package com.cg.iconnect.stepdefinitions;

import org.openqa.selenium.By;
import org.openqa.selenium.By.ByXPath;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.cg.iconnect.beans.IConnect;

import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

@SuppressWarnings("unused")
public class StepDefinition {
	private WebDriver driver;
	private IConnect iconnect;

	@Before
	public void setUpStepEnv(){
		System.setProperty("webdriver.chrome.driver", "D:\\Users\\aralim\\Downloads\\chromedriver.exe");
	}


	@Given("^User is on iconnect HomePage$")
	public void user_is_on_iconnect_HomePage() throws Throwable {
		driver=new ChromeDriver();
		driver.get("https://iconnect.fs.capgemini.com/");
	}

	@When("^User clicks on Leave Management icon$")
	public void user_clicks_on_Leave_Management_icon() throws Throwable {
		Actions action = new Actions(driver);
		WebElement we = driver.findElement(By.xpath("//*[@id='TabbedPanels1']/ul"));
		action.moveToElement(we).moveToElement(driver.findElement(By.xpath("//*[@id='TabbedPanels1']/ul/li[4]"))).click().build().perform();
		WebElement fs = driver.findElement(By.xpath("//*[@id='ctl00_cphMainContent_hplnk_LMS']"));
		fs.click();
	}

	@Then("^display Leave Management$")
	public void display_Leave_Management() throws Throwable {
		 System.out.println(driver.getTitle());
		 driver.navigate().forward();
		 System.out.println(driver.getTitle());
		 driver.close();
		 
	}
	
	@Given("^User is on LMS Page$")
	public void user_is_on_LMS_Page() throws Throwable {
		driver=new ChromeDriver();
		driver.get("https://lms.in.capgemini.com/");
	}

	@When("^User wants to clicks on apply leave$")
	public void user_wants_to_clicks_on_apply_leave() throws Throwable {
	
	   /* WebElement ele = driver.findElement(By.id("1"));
	    ele.click();*/
	    WebElement ele1 = driver.findElement(By.id("6"));
	    ele1.click();
	}

	@Then("^Display the leave page$")
	public void display_the_leave_page() throws Throwable {
	    System.out.println(driver.getTitle());
	   
	}

}
