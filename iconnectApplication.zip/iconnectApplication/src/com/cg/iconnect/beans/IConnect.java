package com.cg.iconnect.beans;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class IConnect {
	
	@FindBy(how=How.XPATH,xpath="//*[@id='ctl00_cphMainContent_lnkClarity']")
	private WebElement clarity;
	
	@FindBy(how=How.XPATH,xpath="//*[@id='ctl00_cphMainContent_lnkSourceForge']")
	private WebElement teamForge;
	
	@FindBy(how=How.XPATH,xpath="//*[@id='ctl00_cphMainContent_lnkTeamx']")
	private WebElement teamX;
	
	@FindBy(how=How.ID,id="ctl00_cphMainContent_lnkKmportal")
	private WebElement FSSBU;
	
	@FindBy(how=How.XPATH,xpath="//*[@id='ctl00_cphMainContent_HyperLink1']")
	private WebElement ITS;
	
	@FindBy(how=How.XPATH,xpath="//*[@id='ctl00_cphMainContent_lnkMarketing']")
	private WebElement FSSBU_Sales;
	
	@FindBy(how=How.XPATH,xpath="//*[@id='ctl00_cphMainContent_HyperLink6']")
	private WebElement Fiona;
	
	@FindBy(how=How.XPATH,xpath="//*[@id='ctl00_cphMainContent_HyperLink8']")
	private WebElement IQMS;
	
	@FindBy(how=How.XPATH,xpath="//*[@id='ctl00_cphMainContent_HyperLink5']")
	private WebElement ICompass;
	
	@FindBy(how=How.XPATH,xpath="//*[@id='ctl00_cphMainContent_lnkProjectSetup']")
	private WebElement PSA;

	@FindBy(how=How.XPATH,xpath="//*[@id='ctl00_cphMainContent_HyperLink3']")
	private WebElement N2K;
	
	@FindBy(how=How.XPATH,xpath="//*[@id='ctl00_cphMainContent_HyperLink3']")
	private WebElement lms;
	
	
}
